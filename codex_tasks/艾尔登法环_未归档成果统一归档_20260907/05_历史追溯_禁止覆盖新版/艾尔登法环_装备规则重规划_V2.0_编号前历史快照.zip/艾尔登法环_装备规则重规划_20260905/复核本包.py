"""校验本包的结构与合成比较。只依赖Python标准库，不写服务器或GitHub。"""
from pathlib import Path
import json, math, hashlib, zipfile, re
import xml.etree.ElementTree as ET

def upper(value):
    if value is None or value == "": return 0.0
    if isinstance(value,(int,float)): return float(value)
    return float(re.split(r"[-~—]",str(value))[-1])
def n(g,k): return float(g.get(k) or 0)
def index(g,b):
    return ((b["raw_attack"]+upper(g.get("攻击"))) *
      (1+(b["attack_pct"]+n(g,"攻击加成"))/100) *
      (1+(b["monster_pct"]+n(g,"打怪伤害"))/100) *
      (1+(b["attack_damage"]+n(g,"攻击伤害"))/100) *
      (1+(b["crit_pct"]+n(g,"暴击几率"))/100*(1+(b["crit_damage"]+n(g,"暴击伤害"))/100)) *
      (1+(b["lethal_pct"]+n(g,"致命几率"))/100*(1+(b["lethal_damage"]+n(g,"致命伤害"))/100)))
def main():
    root=Path(__file__).resolve().parent
    p=json.loads((root/"装备重规划_完整数据.json").read_text(encoding="utf-8"))
    v=json.loads((root/"校验记录.json").read_text(encoding="utf-8"))
    assert len(p["primary_464"])==464 and len(p["supplement_56"])==56 and len(p["crafted_38"])==38
    for old,g in zip(p["original_identity_464"],p["primary_464"]):
        assert old == [g["名称"],g["部位"],g["来源编号"]]
    pools={}
    for g,m in zip(p["primary_464"]+p["supplement_56"],p["primary_metadata"]+p["supplement_metadata"]):
        pools.setdefault(m["id"],[]).append(g["部位"])
    assert all(len(parts)==len(set(parts)) for parts in pools.values())
    for g in p["primary_464"]+p["supplement_56"]+p["crafted_38"]:
        assert n(g,"伤害吸收上限")<=3 and not n(g,"伤害吸收") and not n(g,"幸运")
        if g["部位"]=="武器": assert n(g,"准确")>0 and n(g,"攻击速度")>0
        if g["部位"]=="时装武器": assert not n(g,"攻击速度")
    cases=0
    for t in p["crafted_comparisons"]:
        if "delta_ratio" not in t: continue
        b=p["benchmark_parameters"][str(t["c"])]
        d0,db,ds=index({},b),index(t["base"],b),index(t["new"],b)
        ratio=(ds-d0)/(db-d0)
        assert 2<=ratio<=3
        assert math.isclose(ratio,t["delta_ratio"],rel_tol=1e-10)
        cases+=1
    for f in v["exports"]:
        path=root/f["file"]
        assert hashlib.sha256(path.read_bytes()).hexdigest()==f["sha256"],str(path)
        with zipfile.ZipFile(path) as z:
            assert z.testzip() is None
            for name in z.namelist():
                if re.fullmatch(r"xl/worksheets/sheet\d+\.xml",name):
                    sheet=ET.fromstring(z.read(name))
                    assert not [c for c in sheet.iter("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}c") if c.attrib.get("t")=="e"]
    print(f"通过：464原件身份、56候选部位、{cases}项合成比较、5张XLSX哈希与结构。")
if __name__=="__main__":main()

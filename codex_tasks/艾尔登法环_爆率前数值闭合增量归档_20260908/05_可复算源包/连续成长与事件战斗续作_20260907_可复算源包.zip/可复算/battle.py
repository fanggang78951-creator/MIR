
"""Discrete-event reference combat. Every skill coefficient below is an explicit modeling adapter.
No Magic DB, server script or drop probability is changed.
"""
from pathlib import Path
from collections import Counter
import json,math,random,copy
ROOT=Path(__file__).resolve().parent
SKILLS=[
 {'name':'攻杀剑术','kind':'每3次普通命中候选','cooldown':0,'base_coefficient':1.20,'per_enhance':.02,'targets':1,'unlock_from':None,'priority':0},
 {'name':'烈火剑法','kind':'替代一次普攻','cooldown':7,'base_coefficient':1.80,'per_enhance':.04,'targets':1,'unlock_from':None,'priority':3},
 {'name':'开天斩','kind':'替代一次普攻','cooldown':12,'base_coefficient':2.40,'per_enhance':0,'targets':1,'unlock_from':'攻杀剑术','priority':5},
 {'name':'逐日剑法','kind':'替代一次普攻','cooldown':15,'base_coefficient':2.10,'per_enhance':0,'targets':3,'unlock_from':'基本剑术','priority':4},
 {'name':'双龙斩','kind':'替代一次普攻','cooldown':10,'base_coefficient':1.70,'per_enhance':0,'targets':3,'unlock_from':'半月弯刀','priority':2},
 {'name':'半月弯刀','kind':'普通攻击侧目标','cooldown':0,'base_coefficient':.65,'per_enhance':.01,'targets':3,'unlock_from':None,'priority':0},
 {'name':'十步一杀','kind':'机动/PK；不把位移换成持续DPS','cooldown':None,'base_coefficient':None,'per_enhance':None,'targets':None,'unlock_from':'烈火剑法','priority':0},
 {'name':'群体施毒术','kind':'未证实数值的原脚本效果；主模型不额外赠伤害','cooldown':None,'base_coefficient':None,'per_enhance':None,'targets':None,'unlock_from':'施毒术','priority':0}
]
PARAMS={'hit':.95,'uptime':.80,'crit_base':2,'lethal_base':2,'skill_mode':'explicit_assumptions',
'aoe_lifesteal':'primary_only','first_lifesteal':False,'tail_lifesteal':False,'cut_lifesteal':False,
'aoe_panel_only':True,'incoming_hit':1.,'basic_enhance_damage_per_level':.005,
'potions':False,'resurrection':False,'new_stun':False,'monster_enrage':False,'simulation_timeout_not_enrage':1800}
def execution(points,seconds=0,bonus=0):
 if points<=0:return (0.,0.,1.)
 return (min(1,points/100),1+.2*max(0,points-1)+seconds,2+.2*points+bonus/100)
def choose_skill(p,t,index,cooldowns,mode='normal',scale=1.):
 levels=p['skills']
 if mode=='no_skills':return ('普攻',1.,1)
 choices=[]
 for s in SKILLS:
  if s['cooldown'] and (s['unlock_from'] is None or levels.get(s['unlock_from'],0)>=9) and t>=cooldowns.get(s['name'],0):
   choices.append(s)
 if choices:
  s=max(choices,key=lambda x:x['priority']);cooldowns[s['name']]=t+s['cooldown']
  coef=s['base_coefficient']+s['per_enhance']*levels.get(s['name'],0)
  return s['name'],1+(coef-1)*scale,s['targets']
 if index%3==0:
  coef=1.2+.02*levels.get('攻杀剑术',0)
  return '攻杀剑术',1+(coef-1)*scale,1
 return '普攻',1.,1
def battle(p,monsters,map_config,seed=1,max_seconds=1800,mode='normal',skill_scale=1.,leech_mode='primary_only',invulnerable=False,damage_probe_seconds=None):
 # monster stats are copied; identical identity never gets a different map-variable value per resident.
 rng=random.Random(seed);raw=p['raw'];d=p['derived'];maxhp=float(d['HP']);hp=maxhp;low=hp;t=0.;next_player=0.;index=0
 rate=d['刀每秒'];attack_gap=1/(rate*PARAMS['uptime'])
 entities=[{'m':m,'hp':float(m['HP']),'first':True,'exec_until':0.,'next_hit':m['攻击间隔秒']} for m in monsters]
 cooldowns={};action_counts=Counter();total_damage=0.;total_leech=0.;leech_eligible_damage=0.;incoming=0.;peak_hit=0.;killed=0
 ep,ed,em=execution(max(0,d['处决总百分数']-map_config['execution']),raw['处决时间'],raw['处决倍率'])
 deficit=max(0,map_config['toughness']-raw['韧性']);ip,idur,im=execution(deficit);player_exec_until=0.
 aoe=p.get('aoe');next_aoe=aoe['interval'] if aoe else float('inf')
 cutoff=damage_probe_seconds if damage_probe_seconds else max_seconds
 def damage(e,amount,eligible):
  nonlocal hp,total_damage,total_leech,leech_eligible_damage
  actual=min(max(0,amount),max(0,e['hp']));e['hp']-=actual;total_damage+=actual
  if eligible:
   leech_eligible_damage+=actual;heal=actual*raw['吸血']/100;hp=min(maxhp,hp+heal);total_leech+=heal
  return actual
 while t<cutoff and (hp>0 or invulnerable):
  live=[e for e in entities if e['hp']>0]
  if not live:break
  earliest=min(live,key=lambda e:e['next_hit'])
  nt=min(next_player,next_aoe,earliest['next_hit'],cutoff)
  hp=min(maxhp,hp+raw['每秒回血']*max(0,nt-t));t=nt
  if t>=cutoff:break
  if next_player<=min(next_aoe,earliest['next_hit']):
   next_player+=attack_gap;index+=1
   skill,coef,targets=choose_skill(p,t,index,cooldowns,mode,skill_scale);action_counts[skill]+=1
   hit=(rng.random()<PARAMS['hit'])
   if not hit:continue
   primary=live[0]
   affected=live[:targets]
   if targets==1 and len(live)>1 and skill in ('普攻','攻杀剑术') and mode!='no_skills':
    affected=live[:3]
   for ix,e in enumerate(affected):
    base_attack=rng.uniform(d['面板攻击下限'],d['面板攻击上限']) if d['有效幸运']<12 else d['面板攻击上限']
    if d['有效幸运']<12:
     w=.5+.5*max(0,d['有效幸运'])/12;base_attack=d['面板攻击下限']+(d['面板攻击上限']-d['面板攻击下限'])*w
    # Modest flat armour is removed before ordinary multipliers.
    armor=max(.05,1-e['m']['防御']/max(1,base_attack))
    ordinary=d['期望攻击取值']*d['打怪倍率']*d['伤害系数倍率']*d['神力倍率']*d['攻击伤害倍率']*armor
    crit=PARAMS['crit_base']+raw['暴击伤害']/100 if rng.random()<min(1,raw['暴击几率']/100) else 1.
    lethal=PARAMS['lethal_base']+raw['致命伤害']/100 if rng.random()<min(1,raw['致命几率']/100) else 1.
    mult=coef
    if ix>0 and targets==1:mult=.65+.01*p['skills'].get('半月弯刀',0)
    if mode!='no_skills':mult*=1+PARAMS['basic_enhance_damage_per_level']*p['skills'].get('基本剑术',0)
    if ep and rng.random()<ep:e['exec_until']=t+ed
    ordinary*=crit*lethal*mult*(em if t<e['exec_until'] else 1)
    if e['first']:
     damage(e,e['m']['HP']*min(.5,max(0,raw['首刀斩杀']/100)),False);e['first']=False
    damage(e,ordinary,ix==0 or leech_mode=='all_targets')
    # Flat cutting is not multiplied by critical/skill/execution and not eligible for life steal.
    if ix==0:damage(e,raw['固定切割'],False)
    if e['hp']<=e['m']['HP']*min(.5,max(0,raw['尾刀斩杀']/100)):damage(e,e['hp'],False)
  elif next_aoe<=earliest['next_hit']:
   next_aoe+=aoe['interval'];action_counts['群星之核']+=1
   cap=4 if aoe['range']=='2×2' else 9
   for e in live[:cap]:damage(e,d['期望攻击取值']*aoe['coefficient']*PARAMS['hit'],False)
  else:
   e=earliest;e['next_hit']+=e['m']['攻击间隔秒']
   if ip and rng.random()<ip:player_exec_until=t+idur
   mult=im if t<player_exec_until else 1.
   amount=max(1,rng.uniform(e['m']['攻击下限'],e['m']['攻击上限'])-raw['防御上限'])*(1-d['有效吸收'])*mult
   incoming+=amount;peak_hit=max(peak_hit,amount)
   if not invulnerable:hp-=amount
   low=min(low,hp)
 killed=sum(e['hp']<=0 for e in entities)
 return {'win':killed==len(entities),'seconds':t,'kills':killed,'targets':len(entities),'hp_min_ratio':max(0,low/maxhp),
 'hp_end_ratio':max(0,hp/maxhp),'damage':total_damage,'leech':total_leech,'leech_eligible_damage':leech_eligible_damage,
 'incoming':incoming,'peak_hit_ratio':peak_hit/maxhp,'toughness_gap':raw['韧性']-map_config['toughness'],
 'action_counts':dict(action_counts),'map_toughness':map_config['toughness'],'map_execution':map_config['execution']}
def nominal_dps(p,config,armor=0,seconds=180):
 dummy={'HP':1e30,'攻击下限':0,'攻击上限':0,'攻击间隔秒':1e9,'防御':armor}
 # Remove first/tail from the probing copy, otherwise the arbitrary dummy HP would dominate DPS.
 q=copy.deepcopy(p);q['raw']['首刀斩杀']=0;q['raw']['尾刀斩杀']=0
 r=battle(q,[dummy],config,seed=918372,invulnerable=True,damage_probe_seconds=seconds)
 return r['damage']/seconds

"""Offline pre-drop combat scenarios. No filesystem outside this task; no deployment.
All probabilities below are COMBAT mechanics, never item drop probabilities.
"""
from pathlib import Path
from collections import Counter,defaultdict
import json,math,re,random,copy,hashlib,importlib.util
R=Path(__file__).resolve().parents[1]
S=json.loads((R/'source/snapshot_all.json').read_text())
O=json.loads((R/'source/old_model/source_inputs.json').read_text())
N=json.loads((R/'results/normalized.json').read_text())
sp=importlib.util.spec_from_file_location('legacy_math',R/'source/old_model/build_profiles.py');u=importlib.util.module_from_spec(sp);sp.loader.exec_module(u)
G=N['gear'];M=N['monsters'];MI={m['id']:m for m in M};groups=N['groups'];recipes=N['recipes'];C=N['crafts']
def num(v):return float(v or 0)
def stat(a,v):return u.stat_attr(a,v)
def sumsrc(ss):
 out=defaultdict(float)
 for s in ss:
  for k,v in s['stats'].items():out[k]+=num(v)
 return {k:out.get(k,0.) for k in u.ATTRS}
def src(category,name,stats,rule='沿用已确认值',ids=None):return {'category':category,'name':name,'stats':stats,'rule':rule,'ids':ids or []}
def stable(s):return int.from_bytes(hashlib.sha256(s.encode()).digest()[:8],'big')
def round_sig(v,sig=3):
 if not v:return 0
 scale=10**max(0,int(math.floor(math.log10(abs(v))))-sig+1)
 return max(1,int(math.floor(v/scale+.5)*scale))
# Explicit adapter: legacy code does not determine current policy.
def derive(raw,skill=1.35):
 out=u.derive(raw,skill=skill)
 # Rebuild legacy execution-only outputs under current documented B, not the superseded minus-one multiplier.
 for resist in [0,10,20,30]:
  ep=max(0,min(1,(out['处决总概率百分点']-resist)/100));dur=1+.2*max(0,ep*100-1)+raw['处决时间'] if ep else 0
  mult=2+.2*ep*100+raw['处决倍率']/100 if ep else 1
  cov=1-(1-ep)**max(0,int(math.floor(dur*out['刀每秒']*.95))) if ep else 0
  out[f'处决{resist}_有效概率']=ep;out[f'处决{resist}_覆盖率']=cov;out[f'处决{resist}_窗口倍率']=mult;out[f'处决{resist}_秒']=dur
  out[f'处决{resist}_长战DPS']=(out['暴致命期望单刀']*skill*(1+cov*(mult-1))+raw['固定切割'])*out['刀每秒']*.95*.8
 return out
slot_rows=S['c310']['部位说明'];slotmap={r[0]:r[1] for r in slot_rows[1:] if r[0]}
boxes={r[0]:69+int(r[2]) for r in O['nonmonster']['slot_plan']}
def slots(g):
 part=g['部位']
 if part=='时装首饰盒':return [boxes[g['名称']]]
 if part=='灵玉':return [] # carrier reservation, separately flagged in audit
 value=slotmap.get(part)
 if isinstance(value,(int,float)):return [int(value)]
 if value and '/' in str(value):return [int(a) for a in str(value).split('/')]
 return []
meta={}
for m in M:
 for n in m['items']:meta[n]={'c':m['c'],'group_index':m['group_index'],'group':m['group'],'role':m['role'],'source':m['id']}
for k,c in [('c1',1),('c2sets',2)]:
 rr=S[k]['装备导入表']
 for i,r in enumerate(rr[1:]):
  if r[0] not in meta:meta[r[0]]={'c':c,'group_index':min(len(groups[str(c)])-1,int((i//8)/10*len(groups[str(c)]))),'group':'制式','role':'制式','source':k}
for n,r in C.items():meta[n]={'c':r['c'],'group_index':len(groups[str(r['c'])])-1,'group':'合成','role':'合成','source':r['id']}
assert set(meta)==set(G)
# Actual added collection items use same-stage/source-tier rewards, and are never granted automatically.
collections={r[2]:r for r in S['npc']['07_专属单件图鉴'][4:] if r[2]}
for name in G:
 if name in collections or name not in N['item_sources']:continue
 mm=meta[name];samples=[r for r in collections.values() if int(r[0][1:])==mm['c'] and r[3] in (mm['role'],'BOSS' if mm['role']=='地图BOSS' else mm['role'])]
 if not samples:samples=[r for r in collections.values() if int(r[0][1:])==mm['c']]
 rr=copy.deepcopy(samples[0]);rr[1]=mm['group'];rr[2]=name;rr[3]=mm['role'];collections[name]=rr
page_rewards={(r[0],r[1]):r for r in S['npc']['08_地图整页图鉴'][4:] if r[0]}
page_names=defaultdict(set)
for name,rr in collections.items():page_names[(rr[0],rr[1])].add(name)
title=S['npc']['01_贯穿称号'][4:]
independent=S['npc']['02_独立称号'][4:]
rebirth=S['npc']['03_二十转奖励'][4:]
fates={}
for row in S['fate']['命格定义'][1:]:
 if row[0]:fates[int(row[0])]={'id':int(row[0]),'name':row[2],'q':row[3],'stats':{}}
for row in S['fate']['命格属性'][1:]:
 if row[0]:
  for k,v in stat(row[2],row[3]).items():fates[int(row[0])]['stats'][k]=fates[int(row[0])]['stats'].get(k,0)+v
# Order is a planned reachable build, not a paid guarantee of exact names.
fate_order=[1087,1088,1091,1081,1085,1083,1090,1093]
body_max=[0,50,80,110,140,170,195,220,240,255]
rebirth_max=[0,0,0,5,5,10,10,15,15,20]
# Non-repeating specific builds, only progress-opened slots. No hard cap on total breakthrough is invented.
def fate_count(c,p,post=False):
 n=2
 if c>1 or p>=.35:n=3
 for stage in [2,3,5,7,9]:
  if c>stage or (post and c==stage):n+=1
 return min(8,n)
neck_rng=random.Random(730119); neck_luck=0; neck_trials=0;luck_timeline=[]
while neck_luck<8:
 neck_trials+=1
 if neck_rng.random() < (.024 if neck_trials<=250 else .2):neck_luck+=1
 luck_timeline.append(neck_luck)
assert neck_trials<2000
# Utility is selection scoring only, not asserted engine formula.
def choice_score(g):
 st=u.stats_from_gear(g)
 return (u.pair(g.get('攻击'))[1]+4*st.get('攻击加成',0)+6*st.get('打怪伤害',0)+3*st.get('攻击伤害',0)
         +.00015*st.get('HP',0)+8*st.get('韧性',0)+22*st.get('对怪伤害吸收',0)+40*st.get('伤害吸收上限',0)
         +30*st.get('吸血',0)+80*st.get('攻速突破',0)+8*st.get('攻击速度',0))
# At 70% all preclear craft outputs are made; crafting != simultaneously equipping conflicting slots.
def available(name,c,p,gi=None,local=1.,post=False):
 mm=meta[name]
 if mm['c']>c:return False
 if mm['role']=='合成':return mm['c']<c or (p>=.65 and gi is None)
 if mm['c']<c:return True
 if mm['role']=='守关BOSS':return post
 if gi is not None:
  if mm['group_index']>gi:return False
  if mm['group_index']==gi:
   if mm['role']=='地图BOSS' and local<1:return False
   if mm['role']=='稀有' and local<.4:return False
  return True
 # Continental 50% covers early maps; 70% reaches all map bosses but still no gate.
 lim=math.ceil(len(groups[str(c)])*(.65 if p<.65 else 1))
 return mm['group_index']<lim
WASH_POOL=O['wash_pool'][1:]
def aff_roll(name,rng):
 eligible=[r for r in WASH_POOL if r[1] not in ('攻击','魔法','道术') or u.pair(G[name].get(r[1]))[1]>=2]
 count=rng.choices(range(1,9),[.34,.26,.18,.10,.06,.03,.02,.01])[0]
 out=[]
 for _ in range(count):
  rr=rng.choices(eligible,[r[3] for r in eligible])[0];a=rr[1]
  if a in ('攻击','魔法','道术'):v=rng.randint(1,int(u.pair(G[name].get(a))[1]//2))
  elif a=='攻击加成':lo,hi=u.pair(rr[2]);v=rng.randint(int(lo),int(hi))
  else:v=float(re.findall(r'\d+(?:\.\d+)?',str(rr[2]))[0])
  out.append({'attribute':a,'value':v})
 return out

def profile(c,p,gi=None,local=1.,post=False):
 label=f'C{c:02d}-'+(f'G{gi+1:02d}-{int(local*100):03d}' if gi is not None else ('POST' if post else f'P{int(p*100):02d}'))
 out=[]
 def add(cat,name,stats,rule='沿用已确认值',ids=None):out.append(src(cat,name,stats,rule,ids))
 steps=c-1+p
 natural={'攻击下限':7+2*steps,'攻击上限':13+5*steps,'HP':1000+400*steps,'MP':200+100*steps}
 add('自然','等效等级底板',natural,'推定；不是服务器等级数据库')
 add('付费','第4档赞助',{'处决概率':10,'韧性':50,'爆率':600,'最大爆率':10,'伤害系数':10})
 add('付费','狂暴',{**{k:50 for k in ['攻击下限','攻击上限','魔法下限','魔法上限','道术下限','道术上限']},'HP':10000,'暴击几率':10})
 add('付费','捐献',{**{k:99 for k in ['攻击下限','攻击上限','魔法下限','魔法上限','道术下限','道术上限']},'爆率':100,'最大爆率':5,'暴击几率':10})
 for typ in ['圣律','黄金']:
  b=50 if c==1 else 280
  st={k:b for k in ['攻击下限','攻击上限','魔法下限','魔法上限','道术下限','道术上限']}
  if typ=='圣律':st['固定切割' if c==1 else '鞭尸']=5000 if c==1 else 10
  else:st['每秒回血' if c==1 else '首刀斩杀']=2000 if c==1 else 10
  add('成长装备',('圣律之剑' if typ=='圣律' else '黄金圣物') if c==1 else ('圣律真言' if typ=='圣律' else '黄金之心'),st,'已确认C1不改、C2各280；付费直升路径')
 ti=c-1 if c<=2 or p>=.6 else c-2;t=title[ti]
 st={k:t[3] for k in ['攻击下限','攻击上限','魔法下限','魔法上限','道术下限','道术上限']};st.update(HP=t[4],MP=t[5],爆率=t[6])
 add('贯穿称号',t[2],st,'当前已完成阶段替换旧阶段，不叠加')
 prev=body_max[c-2] if c>1 else 0;curr=body_max[c-1]
 b=int(prev+(curr-prev)*min(1,max(0,p)))
 q=b*(b+1)//2;st={k:q for k in ['攻击下限','攻击上限','魔法下限','魔法上限','道术下限','道术上限']};st['HP']=q*100
 add('长期神印',str(b)+'档',st,'阶段投资情景；不要求C2做满255')
 rb=rebirth_max[c-1] if p>=.65 else (rebirth_max[c-2] if c>1 else 0)
 add('转生',str(rb)+'转',{'神力增量':sum(r[7] for r in rebirth if r[0]<=rb)})
 for r in independent:
  rc=int(r[1][1:])
  if rc>c or rc==c and p<.65:continue
  st={k:r[3] for k in ['攻击下限','攻击上限','魔法下限','魔法上限','道术下限','道术上限']};st.update(HP=r[4],神力增量=r[5],处决概率=r[6],韧性=r[7])
  if rc>=3:st['攻速突破']=1
  if rc==3:st['伤害吸收上限']=1
  if rc==5:st['伤害吸收上限']=2
  add('独立称号',r[2],st,'原奖励＋已批准的突破/吸收配套，当前Q04依赖已修正',ids=[r[0]])
 # Register individual items; no averaged statistical buff. Previous continents assume 85% collection, not all full pages.
 atlas=set()
 for cc in range(1,c+1):
  names=[n for n in collections if meta[n]['c']==cc]
  names.sort(key=lambda n:(meta[n]['group_index'], {'普通':0,'稀有':1,'地图BOSS':2,'守关BOSS':3}.get(meta[n]['role'],9),n))
  feasible=[n for n in names if cc<c or available(n,c,p,gi,local,post)]
  fraction=.85 if cc<c else p
  take=min(len(feasible),int(len(names)*fraction))
  atlas.update(feasible[:take])
 for n in sorted(atlas):
  r=collections[n];st={k:r[8] for k in ['攻击下限','攻击上限','魔法下限','魔法上限','道术下限','道术上限']};st['HP']=r[9]
  add('单件图鉴',n,st,'登记消耗独立实物1件',ids=[n])
 pages=[]
 for key,ns in page_names.items():
  if ns<=atlas:
   r=page_rewards[key];pages.append(key)
   add('地图收集',key[0]+'/'+key[1],{'韧性':r[3],'处决概率':r[4],'神力增量':r[5]},'全页实际名字齐全才发；不是按比例发韧性')
 # Existing C1/C2 quests: keyed to collectible sources. Post-gate quest is optional, never needed for initial clear.
 qdone=[]
 for qst in N['quests']:
  cc=qst['c'];idx=groups[str(cc)].index(qst['group'])
  if cc>c:continue
  if cc==c:
   if qst['postclear'] and not post:continue
   if idx>=max(1,int(len(groups[str(c)])*p)):continue
   if gi is not None and idx>=gi and local<1:continue
  qdone.append(qst['id']);st={}
  for a,v in qst['stats'].items():st.update(stat(a,v))
  add('大陆任务',qst['name'],st,'任务与图鉴分别领取；不再以图鉴完成冒充任务完成',ids=[qst['id']])
 nslots=fate_count(c,p,post)
 selected_fates=fate_order[:nslots]
 assert len(set(selected_fates))==len(selected_fates)
 for fid in selected_fates:add('命格',fates[fid]['name'],fates[fid]['stats'],'指定构筑情景；取得全彩不保证指定名字',[fid])
 trial=0 if c==1 else neck_trials if c>2 or p>=.65 else min(100,neck_trials)
 nl=luck_timeline[trial-1] if trial else 0
 add('人物幸运','武器7＋人物项链进度',{'武器幸运':7,'项链幸运':nl},'项链永久继承；武器祝福油成本忽略')
 # Discrete gear inventory, non-gate current items only. Track duplicate equipped slots as separate instances.
 allowed=[n for n in G if available(n,c,p,gi,local,post)]
 slot_ids=sorted(set(s for n in allowed for s in slots(G[n])))
 eq={};duplicate=Counter()
 base=sumsrc(out)
 for sid in slot_ids:
  candidates=[n for n in allowed if sid in slots(G[n])]
  if not candidates:continue
  candidates.sort(key=lambda n:(choice_score(G[n]),n))
  # Pay for mandatory crafts, and prefer equipping appropriate same-slot crafted output.
  craft_can=[n for n in candidates if n in C and C[n]['c']<=c]
  ordinary=candidates
  quant=.7 if p<.65 else .86 if p<.85 else 1.
  at=int((len(ordinary)-1)*quant);name=ordinary[at]
  if craft_can and p>=.65:name=max(craft_can,key=lambda n:choice_score(G[n]))
  # retain superior previous-stage drops when a percentile pick would be lower
  prior=[n for n in candidates if meta[n]['c']<c and n not in C]
  if prior and choice_score(G[max(prior,key=lambda n:choice_score(G[n]))])>choice_score(G[name]):name=max(prior,key=lambda n:choice_score(G[n]))
  duplicate[name]+=1;iid=hashlib.sha256(f'{name}|{sid}'.encode()).hexdigest()[:12]
  eq[sid]={'slot':sid,'name':name,'instance':iid,'source':meta[name],'affixes':[],'rolls':0}
  add('装备',f'{sid}:{name}',u.stats_from_gear(G[name]),'采用当前批准装备值，未改基础属性',[iid])
 # Small early wash budget, item-instance specific. Two physical copies permit keeping a best result, not phantom lock-affixes.
 order=sorted(eq,key=lambda sid:choice_score(G[eq[sid]['name']]),reverse=True)
 wash_n=0 if c==1 else min(len(order),max(2,int((2+c)*p)))
 wash_cost=Counter();rolls=0
 for rank,sid in enumerate(order[:wash_n]):
  e=eq[sid];rng=random.Random(stable('wash|'+e['instance']))
  tries=max(1,int((3+c)*p));best=[];bestscore=-1
  for _ in range(tries):
   aff=aff_roll(e['name'],rng)
   score=sum((8 if a['attribute']=='攻速突破' else 2 if a['attribute'] in ['攻击速度','伤害系数'] else 1)*a['value'] for a in aff if a['attribute'] not in ['魔法','道术'])
   if score>bestscore:best,bestscore=aff,score
  e['affixes']=best;e['rolls']=tries;rolls+=tries
  row=next((r for r in recipes if r['id']==f'C{max(2,meta[e["name"]]["c"]):02d}-WASH'),None)
  if row:
   for n,v in row['materials'].items():wash_cost[n]+=v*tries
  st=defaultdict(float)
  for a in best:
   for k,v in stat(a['attribute'],a['value']).items():st[k]+=v
  add('装备洗练',e['name']+':'+e['instance'],dict(st),'真实候选池固定种子样本，2件同名实物轮换保留；未开光',[e['instance']])
 raw=sumsrc(out);dp=derive(raw,1.16 if c==1 else 1.35)
 made=[n for n,r in C.items() if r['c']<c or r['c']==c and p>=.65 and gi is None]
 assert not any(meta[e['name']]['role']=='守关BOSS' and meta[e['name']]['c']==c for e in eq.values()) or post
 # Material need is a lower bound for this exact snapshot, not hourly income or completion time.
 need=Counter();gold=yuan=0;payments=[];used_rec=set()
 def payrr(rr):
  nonlocal gold,yuan
  if rr['id'] in used_rec:return
  used_rec.add(rr['id']);gold+=rr['gold'];yuan+=rr['yuan'];need.update(rr['materials']);payments.append(rr['id'])
 # Distinct inventory demand: wearing, backup wash copy, consumed atlas copies, mandatory first production.
 stock_need=Counter()
 for e in eq.values():stock_need[e['name']]+=2 if e['rolls'] else 1
 for n in atlas:stock_need[n]+=1
 def craft_depth(n,seen=()):
  assert n not in seen,('craft cycle',n)
  return 1+max([craft_depth(x,seen+(n,)) for x in C[n]['bases'] if x in C] or [0])
 batches={}
 for n in sorted(C,key=craft_depth,reverse=True):
  rr=C[n];qty=max(stock_need[n],1 if n in made else 0)
  if not qty:continue
  batches[n]=qty;gold+=rr['gold']*qty;yuan+=rr['yuan']*qty;payments.append(rr['id']+':批次='+str(qty))
  for z,v in rr['materials'].items():need[z]+=v*qty
  for z,v in rr['bases'].items():stock_need[z]+=v*qty
 for n,qty in stock_need.items():
  if n not in C:need['装备:'+n]+=qty
 for cc in range(1,ti+2):
  rr=next(r for r in recipes if r['id']==f'C{cc:02d}-LONGTITLE')
  if cc<=2:payments.append(rr['id']+':灵符路线（既有价格，不估算兑换率）')
  else:payrr(rr)
 for r in independent:
  if int(r[1][1:])<c or int(r[1][1:])==c and p>=.65:payrr(next(rr for rr in recipes if rr['id']==r[0]))
 for r in rebirth:
  if r[0]<=rb:
   rr=next(rr for rr in recipes if rr['type']=='转生' and rr['output'].startswith('第'+str(r[0])+'转'))
   payrr(rr)
 for r in S['econ']['10_神印255档'][4:]:
  if r[0] and r[0]<=b:need['野兽骨片']+=r[3];gold+=r[4];yuan+=r[5]
 need.update(wash_cost)
 for e in eq.values():
  rr=next((r for r in recipes if r['id']==f'C{max(2,meta[e["name"]]["c"]):02d}-WASH'),None)
  if rr:gold+=rr['gold']*e['rolls'];yuan+=rr['yuan']*e['rolls']
 for qid in qdone:need.update(next(q['materials'] for q in N['quests'] if q['id']==qid))
 if trial:
  rr=next((r for r in recipes if 'LUCK' in r['id']),None)
  if rr:
   for n,v in rr['materials'].items():need[n]+=v*trial
   gold+=rr['gold']*trial;yuan+=rr['yuan']*trial
 nc=sum(meta[n]['c']==c for n in atlas);total=sum(meta[n]['c']==c for n in collections)
 return {'id':label,'c':c,'progress_label':p,'group_index':gi,'local_phase':local,'postclear':post,'sources':out,'raw':raw,'derived':dp,
 'gear':list(eq.values()),'fates':selected_fates,'body_level':b,'rebirth':rb,'title_stage':ti+1,'atlas':sorted(atlas),'complete_pages':pages,
 'quests':qdone,'made_crafts':made,'wash_instances':wash_n,'wash_rolls':rolls,'luck_trials':trial,'current_collection_ratio':nc/total,
 'cost_lower_bound':{'gold':gold,'yuan':yuan,'materials':dict(need),'payment_rows':payments,'craft_batches':batches,'stock_requirement':dict(stock_need)},'note':'自产投入情景；概率未定，未证明多久取得。单件装备/任务实物消费分账。'}
# Create 30 preclear scenarios + 10 postclear; also 138 map-group progress scenarios.
P=[];lookup={}
for c in range(1,11):
 for p in [.5,.7,.9]:
  pr=profile(c,p);P.append(pr);lookup[pr['id']]=pr
 pr=profile(c,.9,post=True);P.append(pr);lookup[pr['id']]=pr
for c in range(1,11):
 ng=len(groups[str(c)])
 for gi in range(ng):
  for local in [0.,.5,1.]:
   p=max(.08,(gi+local)/ng)
   pr=profile(c,p,gi,local);P.append(pr);lookup[pr['id']]=pr
# Design monster stats from current mid-map or 70% preclear profile; never from their own dropped item.
MON=[];map_requirements=[]
for c in range(1,11):
 ng=len(groups[str(c)])
 for gi,g in enumerate(groups[str(c)]):
  entry=lookup[f'C{c:02d}-G{gi+1:02d}-000'];mid=lookup[f'C{c:02d}-G{gi+1:02d}-050'];done=lookup[f'C{c:02d}-G{gi+1:02d}-100']
  threshold=0 if c==1 and gi==0 else max(0,math.floor(mid['raw']['韧性']-4))
  er=round(mid['derived']['处决总概率百分点']*.68,1)
  map_requirements.append({'c':c,'group_index':gi,'group':g,'toughness_requirement':threshold,'execution_requirement':er,'reference_profile':mid['id'],
    'scope':'地图组普通/稀有/地图BOSS参考；守关房有独立设定。需要现有地图脚本绑定，未声称数据库原生字段。'})
for m in M:
 c=m['c'];gi=m['group_index'];gate=m['role']=='守关BOSS'
 pr=lookup[f'C{c:02d}-P70'] if gate else lookup[f'C{c:02d}-G{gi+1:02d}-050']
 md=next(r for r in map_requirements if r['c']==c and r['group_index']==gi)
 rng=random.Random(stable(m['id']));style=.9+.2*rng.random()
 ttk=([90,180,220,240,260,280,300,320,340,360][c-1] if gate else {'普通':4+min(c,8)*.5,'稀有':16+c,'地图BOSS':70+10*c}[m['role']]*style)
 # modest ordinary defense; actual values separate from effects and target probabilities
 defense=round_sig(pr['derived']['面板攻击上限']*.06*(1.3 if m['role']=='地图BOSS' else 1))
 phys_factor=max(.05,1-defense/max(1,pr['derived']['期望攻击取值']))
 threshold=max(0,math.floor(pr['raw']['韧性']-2)) if gate else md['toughness_requirement']
 exreq=round(pr['derived']['处决总概率百分点']-(6 if c==1 else 8),1) if gate else md['execution_requirement']
 exreq=max(0,exreq);q=max(0,min(1,(pr['derived']['处决总概率百分点']-exreq)/100))
 dur=1+.2*max(0,q*100-1)+pr['raw']['处决时间'] if q else 0
 multiplier=2+.2*q*100+pr['raw']['处决倍率']/100 if q else 1
 covered=1-(1-q)**max(1,int(dur*pr['derived']['刀每秒']*.95)) if q else 0
 dps=pr['derived']['有效常规DPS']*phys_factor*(1+covered*(multiplier-1))
 first=max(0,min(.5,pr['raw']['首刀斩杀']/100));tail=max(0,min(.5,pr['raw']['尾刀斩杀']/100))
 hp=round_sig(ttk*dps/max(.01,1-first-tail))
 interval={'普通':1.7,'稀有':1.5,'地图BOSS':1.4,'守关BOSS':1.2}[m['role']]
 hp_p=pr['derived']['HP'];absorb=pr['derived']['有效吸收'];heal=pr['derived']['吸血理论上限每秒']*phys_factor
 # Large HP plus negative-toughness exposure: a gate's non-execution hit is at most 16% of reference HP (C1 healing cap lower).
 perhit_fraction=.025 if m['role']=='普通' else .04 if m['role']=='稀有' else .065 if m['role']=='地图BOSS' else .16
 attack=max(hp_p*perhit_fraction/(1-absorb),heal*interval*.85/(1-absorb))
 attack=min(attack,hp_p*(.16 if gate else .10)/(1-absorb))
 if c==1:
  attack=min(attack,(heal+pr['raw']['每秒回血'])*interval*.90/(1-absorb))
 if c==1 and gi==0 and not gate:attack=min(30,attack)
 dc=round_sig(attack+pr['raw']['防御上限']);ac=round_sig(dc*.82)
 out={**m,'HP':hp,'攻击下限':ac,'攻击上限':dc,'防御':defense,'魔御':round_sig(defense*.8),'攻击间隔秒':interval,
 '等级':40+(c-1)*10+gi*2,'经验':round_sig((120+c*80)*(1+gi*.15)*{'普通':1,'稀有':4,'地图BOSS':30,'守关BOSS':100}[m['role']]),
 '地图韧性要求':threshold,'地图处决要求':exreq,'基准人物':pr['id'],'目标击杀秒':ttk,'反算净DPS':dps,
 'model_assumptions':['防御按固定值先扣攻击；未实服验证','首刀/尾刀按已有描述近似扣有效血量','PVE处决窗口按文档B口径近似；战斗模拟另列','不在数据库伪造地图韧性字段'],
 'status':'离线初稿；须以情景结果判断，非已部署最终值'}
 MON.append(out)
# Discrete event survival check. No invented stun, potion, resurrection, immunity or enrage.
def battle(pr,m,seed=1,maxsecs=1800):
 rng=random.Random(seed);d=pr['derived'];raw=pr['raw'];php=d['HP'];mhp=float(m['HP']);mpmax=mhp
 phit=1/d['刀每秒'];mhits=m['攻击间隔秒'];t=0;np=0;nm=mhits;pdebuff=mbuff=0;first=True;minp=php
 exec_p=max(0,min(1,(d['处决总概率百分点']-m['地图处决要求'])/100))
 negative=max(0,m['地图韧性要求']-raw['韧性']);incoming_p=min(1,negative/100)
 done=0.;regen=raw['每秒回血'];ordinary=d['暴致命期望单刀']*d['技能系数']*.8 # downtime amortized, no hidden state
 armor=max(.05,1-m['防御']/max(1,d['期望攻击取值']))
 while t<maxsecs and php>0 and mhp>0:
  now=min(np,nm);php=min(d['HP'],php+regen*(now-t));t=now
  if np<=nm:
   np+=phit
   if rng.random()>.95:continue
   if exec_p and rng.random()<exec_p:mbuff=t+1+.2*max(0,exec_p*100-1)+raw['处决时间']
   dmg=ordinary*armor*(2+.2*exec_p*100+raw['处决倍率']/100 if t<mbuff else 1)+raw['固定切割']*.8
   if first:
    mhp-=mpmax*min(.5,raw['首刀斩杀']/100);first=False
   actual=min(mhp,max(0,dmg));ordinary_actual=min(mhp,max(0,dmg-raw['固定切割']*.8));mhp-=actual;done+=actual
   php=min(d['HP'],php+ordinary_actual*raw['吸血']/100) # excludes first/tail and overkill
   if mhp<=mpmax*min(.5,raw['尾刀斩杀']/100):mhp=0
  else:
   nm+=mhits
   if incoming_p and rng.random()<incoming_p:pdebuff=t+1+.2*max(0,negative-1)
   mult=2+.2*negative if t<pdebuff else 1
   dmg=max(1,rng.uniform(m['攻击下限'],m['攻击上限'])-raw['防御上限'])*(1-d['有效吸收'])*mult
   php-=dmg;minp=min(minp,php)
  if mhp<=0:return {'win':True,'seconds':t,'min_hp_ratio':max(0,minp/d['HP']),'hp_end_ratio':max(0,php/d['HP'])}
 return {'win':False,'seconds':t,'min_hp_ratio':max(0,minp/d['HP']),'hp_end_ratio':max(0,php/d['HP'])}
B=[]
for m in MON:
 if m['role']!='守关BOSS':continue
 for pp in [50,70,90]:
  pr=lookup[f'C{m["c"]:02d}-P{pp}'];sims=[battle(pr,m,10000*m['c']+i) for i in range(40)]
  wins=[s for s in sims if s['win']]
  B.append({'c':m['c'],'boss':m['name'],'profile':pr['id'],'label_pct':pp,'runs':40,'wins':len(wins),'win_rate':len(wins)/40,
   'mean_win_seconds':sum(s['seconds'] for s in wins)/len(wins) if wins else None,'mean_end_hp':sum(s['hp_end_ratio'] for s in sims)/40,
   'toughness':pr['raw']['韧性'],'required':m['地图韧性要求'],'gap':pr['raw']['韧性']-m['地图韧性要求'],
   'note':'仅固定配装下战斗事件抽样；无掉率/取得时间结论，未额外添加眩晕机制'})
# Same exact P70 kit, ONLY toughness changed: isolate whether negative toughness matters.
A=[]
for m in MON:
 if m['role']!='守关BOSS':continue
 for deficit in [0,5,10,25,50]:
  pr=copy.deepcopy(lookup[f'C{m["c"]:02d}-P70']);pr['raw']['韧性']=m['地图韧性要求']-deficit
  sims=[battle(pr,m,30000*m['c']+i) for i in range(30)]
  wins=[x for x in sims if x['win']]
  A.append({'c':m['c'],'boss':m['name'],'deficit':deficit,'runs':30,'wins':len(wins),'win_rate':len(wins)/30,
    'mean_win_seconds':sum(x['seconds'] for x in wins)/len(wins) if wins else None,
    'other_stats_unchanged':True,'purpose':'只改韧性，隔离高HP/高吸血能否绕过韧性不足'})
summary={'profiles':len(P),'continent_preclear_profiles':30,'postclear_profiles':10,'map_group_profiles':138,
 'monsters':len(MON),'gate_scenarios':len(B),'battle_trials':len(B)*40+len(A)*30,'toughness_ablation_scenarios':len(A),'same_fate_duplicates':0,
 'first_clear_current_gate_gear':0,'rewards_collection_entries':len(collections),'neck_luck8_trial_model':neck_trials,
 'all_70_pass':all(b['win_rate']>=.9 for b in B if b['label_pct']==70),
 'all_50_blocked':all(b['win_rate']<=.25 for b in B if b['label_pct']==50),
 'status':'未确定掉落概率/时长；模拟失败项如实保留，不以改报告伪造通过'}
J={'profiles':P,'monsters':MON,'map_requirements':map_requirements,'boss_scenarios':B,'toughness_ablations':A,'collection_rows':list(collections.values()),'summary':summary}
(R/'results/combat.json').write_text(json.dumps(J,ensure_ascii=False,indent=2))
print(json.dumps(summary,ensure_ascii=False,indent=2))
for b in B:print(b['c'],b['label_pct'],b['toughness'],b['required'],b['win_rate'],round(b['mean_win_seconds'] or 0,1))

import fs from "node:fs/promises";
import path from "node:path";
import { FileBlob, SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const root = "/workspace/scratch/f124f410aa49";
const batchDir = path.join(root, "monster_naming_batches");
const outputDir = path.join(root, "outputs", "f124f410aa49");
const previewDir = path.join(outputDir, "c3_c10_ledger_previews");
const outputPath = path.join(outputDir, "第3至10大陆_怪物专属与材料来源总账_V1.0.xlsx");
const verifyPath = outputPath + ".verify.json";

const source = {
  c1Monsters: path.join(root, "deliverables", "艾尔登法环_第一二大陆_Codex施工包_20260821", "01_第一大陆36怪_属性修改表.xlsx"),
  c2Monsters: path.join(root, "deliverables", "艾尔登法环_第一二大陆_Codex施工包_20260821", "02_第二大陆宁姆格福61怪_属性修改表.xlsx"),
  exclusives: path.join(root, "deliverables", "艾尔登法环_第一二大陆_Codex施工包_20260821", "04_第一二大陆105件专属装备_属性修改表.xlsx"),
  standard: path.join(root, "source_products_latest", "艾尔登法环_20套制式装备.xlsx"),
  materials: path.join(root, "material_import_phase_a_extracted", "material_import_phase_a", "04_材料正式入库.json"),
};

const expected = {
  C03: { continent: "宁姆格福西域", groups: 6, maps: 20, monsters: 73 },
  C04: { continent: "利耶尼亚海域", groups: 6, maps: 17, monsters: 73 },
  C05: { continent: "湖之利耶尼亚", groups: 6, maps: 22, monsters: 73 },
  C06: { continent: "盖利德", groups: 3, maps: 15, monsters: 37 },
  C07: { continent: "化圣雪原", groups: 3, maps: 13, monsters: 37 },
  C08: { continent: "巨人山顶", groups: 4, maps: 16, monsters: 49 },
  C09: { continent: "亚坛高原", groups: 5, maps: 22, monsters: 61 },
  C10: { continent: "王城罗德尔", groups: 5, maps: 19, monsters: 61 },
};

const allowedSlots = ["武器", "衣服", "头盔", "项链", "手镯", "戒指", "腰带", "鞋子", "斗笠", "盾牌", "勋章"];
const forbiddenSlots = ["马牌", "战鼓", "军鼓", "灵玉", "宝石", "时装首饰盒", "生肖"];
const rarityOrder = ["普通", "稀有", "地图BOSS"];
const colorByRarity = { "普通": "黄色", "稀有": "蓝色", "地图BOSS": "粉色", "守关BOSS": "红色" };

function invariant(condition, message) {
  if (!condition) throw new Error(message);
}

function duplicates(values) {
  const counts = new Map();
  for (const value of values) counts.set(value, (counts.get(value) ?? 0) + 1);
  return [...counts.entries()].filter(([, count]) => count > 1).map(([value]) => value);
}

function rarityCounts(rows) {
  return Object.fromEntries(["普通", "稀有", "地图BOSS", "守关BOSS"].map((key) => [key, rows.filter((row) => row.rarity === key).length]));
}

const continentIds = Object.keys(expected);
const batches = [];
for (const continentId of continentIds) {
  const file = path.join(batchDir, continentId.toLowerCase() + ".json");
  const data = JSON.parse(await fs.readFile(file, "utf8"));
  invariant(data.continent_id === continentId, continentId + " continent_id不一致");
  invariant(data.continent === expected[continentId].continent, continentId + " 大陆名不一致");
  invariant(Array.isArray(data.groups) && data.groups.length === expected[continentId].groups, continentId + " 地图组数量异常");
  invariant(data.continent_collectible?.name, continentId + " 缺大陆收藏材料名");
  batches.push(data);
}

const monsterRows = [];
const mapRows = [];
const slotCoverageWarnings = [];
for (const batch of batches) {
  let sequence = 1;
  batch.groups.forEach((group, groupIndex) => {
    invariant(Array.isArray(group.maps) && group.maps.length >= 2, batch.continent_id + "/" + group.group + " 地图链为空");
    invariant(Array.isArray(group.monsters) && group.monsters.length === 12, batch.continent_id + "/" + group.group + " 应为12怪");
    const counts = rarityCounts(group.monsters);
    invariant(counts["普通"] === 6 && counts["稀有"] === 4 && counts["地图BOSS"] === 2, batch.continent_id + "/" + group.group + " 分类不是6/4/2");
    const mapById = new Map(group.maps.map((map, mapIndex) => [map.id, { ...map, layer: mapIndex + 1 }]));
    invariant(mapById.size === group.maps.length, batch.continent_id + "/" + group.group + " 地图号重复");
    const ordinaryMaps = new Set();
    const rareMaps = new Set();
    const lastTwo = new Set(group.maps.slice(-2).map((map) => map.id));
    const groupSlots = new Set();
    group.monsters.forEach((monster) => {
      invariant(rarityOrder.includes(monster.rarity), batch.continent_id + "/" + group.group + " 存在非法类别");
      const map = mapById.get(monster.map_id);
      invariant(map, batch.continent_id + "/" + group.group + "/" + monster.name + " 地图号不属于本组");
      invariant(monster.map_name === map.name, batch.continent_id + "/" + group.group + "/" + monster.name + " 地图名称与地图号不符");
      invariant(allowedSlots.includes(monster.slot), batch.continent_id + "/" + monster.name + " 非法部位：" + monster.slot);
      invariant(!forbiddenSlots.some((slot) => monster.slot.includes(slot)), batch.continent_id + "/" + monster.name + " 使用禁用部位：" + monster.slot);
      invariant(monster.name && monster.exclusive && monster.archetype && monster.combat_role, batch.continent_id + "/" + group.group + " 存在空命名或分类");
      if (monster.rarity === "普通") ordinaryMaps.add(monster.map_id);
      if (monster.rarity === "稀有") rareMaps.add(monster.map_id);
      if (monster.rarity === "地图BOSS") invariant(lastTwo.has(monster.map_id), batch.continent_id + "/" + monster.name + " BOSS不在最后两图");
      groupSlots.add(monster.slot);
      monsterRows.push({
        recordId: batch.continent_id + "-M" + String(sequence++).padStart(3, "0"),
        continentId: batch.continent_id,
        continent: batch.continent,
        groupOrder: groupIndex + 1,
        group: group.group,
        layer: map.layer,
        mapId: monster.map_id,
        mapName: monster.map_name,
        ...monster,
      });
    });
    invariant(ordinaryMaps.size === group.maps.length, batch.continent_id + "/" + group.group + " 普通怪未覆盖全部地图");
    invariant(rareMaps.size === Math.min(4, group.maps.length), batch.continent_id + "/" + group.group + " 稀有怪地图覆盖不足");
    if (groupSlots.size < 9) slotCoverageWarnings.push(batch.continent_id + "/" + group.group + "仅覆盖" + groupSlots.size + "个部位");
    group.maps.forEach((map, mapIndex) => {
      mapRows.push({
        recordId: batch.continent_id + "-MAP-" + String(mapRows.filter((row) => row.continentId === batch.continent_id).length + 1).padStart(3, "0"),
        continentId: batch.continent_id,
        continent: batch.continent,
        groupOrder: groupIndex + 1,
        group: group.group,
        layer: mapIndex + 1,
        mapId: map.id,
        mapName: map.name,
      });
    });
  });
  const lastGroup = batch.groups.at(-1);
  const lastMap = lastGroup.maps.at(-1);
  const finalBoss = batch.final_boss;
  invariant(finalBoss?.rarity === "守关BOSS", batch.continent_id + " 守关BOSS类别错误");
  invariant(finalBoss.map_id === lastMap.id && finalBoss.map_name === lastMap.name, batch.continent_id + " 守关BOSS未在大陆最终图");
  invariant(allowedSlots.includes(finalBoss.slot), batch.continent_id + " 守关BOSS非法部位");
  invariant(!forbiddenSlots.some((slot) => finalBoss.slot.includes(slot)), batch.continent_id + " 守关BOSS使用禁用部位");
  monsterRows.push({
    recordId: batch.continent_id + "-M" + String(sequence++).padStart(3, "0"),
    continentId: batch.continent_id,
    continent: batch.continent,
    groupOrder: batch.groups.length,
    group: lastGroup.group,
    layer: lastGroup.maps.length,
    mapId: finalBoss.map_id,
    mapName: finalBoss.map_name,
    ...finalBoss,
  });
  invariant(sequence - 1 === expected[batch.continent_id].monsters, batch.continent_id + " 怪物总数异常");
}

invariant(monsterRows.length === 464, "C3-C10怪物总数应为464");
invariant(mapRows.length === 144, "C3-C10地图总数应为144");
const totalRarity = rarityCounts(monsterRows);
invariant(totalRarity["普通"] === 228, "普通怪应为228");
invariant(totalRarity["稀有"] === 152, "稀有怪应为152");
invariant(totalRarity["地图BOSS"] === 76, "地图BOSS应为76");
invariant(totalRarity["守关BOSS"] === 8, "守关BOSS应为8");
invariant(duplicates(monsterRows.map((row) => row.name)).length === 0, "C3-C10怪物名称重复：" + duplicates(monsterRows.map((row) => row.name)).join("、"));
invariant(duplicates(monsterRows.map((row) => row.exclusive)).length === 0, "C3-C10专属名称重复：" + duplicates(monsterRows.map((row) => row.exclusive)).join("、"));
invariant(duplicates(mapRows.map((row) => row.mapId)).length === 0, "地图号重复：" + duplicates(mapRows.map((row) => row.mapId)).join("、"));

const importBook = async (file) => SpreadsheetFile.importXlsx(await FileBlob.load(file));
const [c1Book, c2Book, exclusiveBook, standardBook] = await Promise.all([
  importBook(source.c1Monsters),
  importBook(source.c2Monsters),
  importBook(source.exclusives),
  importBook(source.standard),
]);
const c1Names = c1Book.worksheets.getItem("怪物生成").getRange("B2:B37").values.flat().filter(Boolean);
const c2Names = c2Book.worksheets.getItem("怪物生成").getRange("B2:B62").values.flat().filter(Boolean);
const oldMonsterNames = new Set([...c1Names, ...c2Names]);
const monsterCollisions = monsterRows.map((row) => row.name).filter((name) => oldMonsterNames.has(name));
invariant(monsterCollisions.length === 0, "与第一二大陆怪名重复：" + monsterCollisions.join("、"));

const oldExclusiveNames = new Set([
  ...exclusiveBook.worksheets.getItem("装备导入表").getRange("A2:A106").values.flat().filter(Boolean),
  ...standardBook.worksheets.getItem("装备导入表").getRange("A2:A161").values.flat().filter(Boolean),
]);
const equipmentCollisions = monsterRows.map((row) => row.exclusive).filter((name) => oldExclusiveNames.has(name));
invariant(equipmentCollisions.length === 0, "与现有装备名称重复：" + equipmentCollisions.join("、"));

const formalMaterials = JSON.parse(await fs.readFile(source.materials, "utf8")).materials;
const formalByLogicalId = new Map(formalMaterials.map((row) => [row.logicalMaterialId, row]));
const materialRows = [];
const materialByContinent = new Map();
const sourceLabels = {
  COM: ["全部怪物", "全大陆地图", "大陆通用合成、升级及基础消耗"],
  RARE: ["稀有怪／地图BOSS／守关BOSS", "全大陆地图", "稀有合成与中高阶消耗"],
  MARK: ["地图BOSS／守关BOSS", "全大陆BOSS地图", "剧情、称号及重点合成"],
  Q01: ["普通怪", "全大陆普通怪", "普通怪身份凭证"],
  Q02: ["稀有怪", "全大陆稀有怪", "稀有怪身份凭证"],
  Q03: ["地图BOSS", "全大陆地图BOSS", "地图BOSS身份凭证"],
  Q04: ["守关BOSS", "大陆最终图", "守关BOSS身份凭证"],
};
for (const batch of batches) {
  const entries = {};
  for (const suffix of ["COM", "RARE", "MARK", "Q01", "Q02", "Q03", "Q04"]) {
    const logicalId = "EL-MAT-" + batch.continent_id + "-" + suffix;
    const row = formalByLogicalId.get(logicalId);
    invariant(row, "材料库缺少 " + logicalId);
    entries[suffix] = row;
    const labels = sourceLabels[suffix];
    materialRows.push({
      recordId: batch.continent_id + "-MAT-" + suffix,
      continentId: batch.continent_id,
      continent: batch.continent,
      logicalId,
      name: row.name,
      category: row.category,
      idx: row.actualIdx,
      looks: row.looks,
      producer: labels[0],
      scope: labels[1],
      purpose: labels[2],
      status: "已正式入库",
      note: "Idx与Items Looks锁定，不得改名、改号或覆盖",
    });
  }
  const collectionName = batch.continent_collectible.name;
  invariant(!formalMaterials.some((row) => row.name === collectionName), batch.continent_id + " 大陆收藏材料与现有材料重名");
  materialRows.push({
    recordId: batch.continent_id + "-MAT-COLLECT",
    continentId: batch.continent_id,
    continent: batch.continent,
    logicalId: "EL-MAT-" + batch.continent_id + "-COLLECT",
    name: collectionName,
    category: "大陆收藏材料",
    idx: null,
    looks: null,
    producer: "全部怪物（独立判定）",
    scope: "全大陆所有地图",
    purpose: "不可装备；只供高价值大陆图鉴收集",
    status: "名称定稿／编码待分配",
    note: batch.continent_collectible.note || "暂不占用Idx 972—983冻结预留段",
  });
  materialByContinent.set(batch.continent_id, { ...entries, COLLECT: collectionName });
}
invariant(materialRows.length === 64, "材料来源行应为64");
invariant(duplicates(batches.map((batch) => batch.continent_collectible.name)).length === 0, "大陆收藏材料重名");

const monsterSheetRows = monsterRows.map((row) => {
  const materials = materialByContinent.get(row.continentId);
  const rareStory = row.rarity === "普通" ? "" : row.rarity === "稀有" ? materials.RARE.name : materials.RARE.name + "＋" + materials.MARK.name;
  const evidence = row.rarity === "普通" ? materials.Q01.name : row.rarity === "稀有" ? materials.Q02.name : row.rarity === "地图BOSS" ? materials.Q03.name : materials.Q04.name;
  return [
    row.recordId, row.continentId, row.continent, row.groupOrder, row.group, row.layer,
    row.mapId, row.mapName, row.name, colorByRarity[row.rarity], row.rarity,
    row.archetype, row.combat_role, row.exclusive, row.slot, materials.COM.name,
    rareStory, evidence, materials.COLLECT,
    ["地图BOSS", "守关BOSS"].includes(row.rarity) ? "是（独立奖池）" : "否",
    "是（公共奖池）", "结构定稿", "待平台分配", "待实库回读分配",
    "后期统一平衡",
    row.rarity === "守关BOSS" ? "大陆最终守关；本表不填属性、爆率和货币" : "一怪一专属；专属来源跟随本行准确地图号",
  ];
});

const artifacts = [
  ["ART-01", "玛莲妮亚的大卢恩", 5909],
  ["ART-02", "拉塔恩的大卢恩", 5954],
  ["ART-03", "蒙葛特的大卢恩", 5999],
  ["ART-04", "蒙格的大卢恩", 6044],
  ["ART-05", "拉卡德的大卢恩", 6089],
  ["ART-06", "葛瑞克的大卢恩", 6125],
];

const theme = {
  navy: "#1F2937",
  gold: "#B78B2E",
  pale: "#F4F1E8",
  border: "#D8D2C4",
  text: "#20242A",
  green: "#E5F3E8",
  yellow: "#FFF3CD",
  blue: "#E8EEF7",
  red: "#FBE4E6",
  cyan: "#DDF3F8",
  purple: "#EFE6FA",
};

function title(sheet, rangeAddress, value) {
  const range = sheet.getRange(rangeAddress);
  range.merge();
  range.values = [[value]];
  range.format = {
    fill: theme.navy,
    font: { name: "Noto Sans SC Thin", size: 16, bold: true, color: "#FFFFFF" },
    verticalAlignment: "center",
  };
  range.format.rowHeight = 34;
}

function subtitle(sheet, rangeAddress, value) {
  const range = sheet.getRange(rangeAddress);
  range.merge();
  range.values = [[value]];
  range.format = {
    fill: theme.pale,
    font: { name: "Noto Sans SC Thin", size: 10, color: "#4B5563" },
    verticalAlignment: "center",
    wrapText: true,
  };
  range.format.rowHeight = 40;
}

function styleHeader(range) {
  range.format = {
    fill: theme.gold,
    font: { name: "Noto Sans SC Thin", size: 10, bold: true, color: "#FFFFFF" },
    horizontalAlignment: "center",
    verticalAlignment: "center",
    wrapText: true,
    borders: { preset: "all", style: "thin", color: theme.border },
  };
  range.format.rowHeight = 32;
}

function styleBody(range, rowHeight = 24) {
  range.format = {
    font: { name: "Noto Sans SC Thin", size: 10, color: theme.text },
    verticalAlignment: "center",
    wrapText: true,
    borders: {
      insideHorizontal: { style: "thin", color: "#E7E2D8" },
      bottom: { style: "thin", color: "#E7E2D8" },
    },
  };
  range.format.rowHeight = rowHeight;
}

function setWidths(sheet, widths) {
  for (const [column, width] of Object.entries(widths)) {
    sheet.getRange(column + ":" + column).format.columnWidth = width;
  }
}

function addTable(sheet, address, name) {
  const table = sheet.tables.add(address, true, name);
  table.style = "TableStyleMedium2";
  table.showBandedRows = true;
  table.showFilterButton = true;
}

const book = Workbook.create();
const guide = book.worksheets.add("00_使用说明");
const maps = book.worksheets.add("01_地图总览");
const monsters = book.worksheets.add("02_怪物与专属");
const materials = book.worksheets.add("03_材料来源");
const slots = book.worksheets.add("04_部位统计");
const pools = book.worksheets.add("05_独立奖池与六神器");
const checks = book.worksheets.add("06_校验报告");
const codes = book.worksheets.add("07_编码与后续");
for (const sheet of [guide, maps, monsters, materials, slots, pools, checks, codes]) sheet.showGridLines = false;

const monsterStart = 5;
const monsterEnd = monsterStart + monsterSheetRows.length - 1;
const mapStart = 5;
const mapEnd = mapStart + mapRows.length - 1;
const materialStart = 5;
const materialEnd = materialStart + materialRows.length - 1;

title(guide, "A1:H1", "第3—10大陆怪物、专属与材料来源总账 V1.0");
subtitle(guide, "A2:H2", "结构已确认：以38组、144张已完成地图为骨架，落定464只怪物、464件一怪一专属和材料来源关系。当前阶段不填写怪物属性、装备属性、货币数值、材料数量或具体爆率。");
guide.getRange("A4:H12").values = [
  ["检查项", "数量", "状态", "现行口径", "本表是否落定", "后续阶段", "禁止事项", "说明"],
  ["大陆", 8, "已覆盖", "第3—10大陆", "是", "无", "不得恢复旧13大陆正式范围", "第11—13大陆只作未来预留"],
  ["地图组", 38, "已覆盖", "每组形成独立怪物生态", "是", "无", "不得改现有地图组", "所有怪物落到准确地图号"],
  ["地图", 144, "已覆盖", "逐层登记", "是", "平台连接复核", "不得把层位范围当地图号", "C9—C10层序来自最新地图总览"],
  ["怪物", null, "结构定稿", "每组6普通＋4稀有＋2地图BOSS；每大陆另1守关", "是", "模型／编码", "本阶段不填数值", "合计464"],
  ["一怪一专属", null, "结构定稿", "每怪1件唯一专属", "是", "来源编号／属性", "马牌、战鼓、灵玉、宝石不得参与", "六个时装首饰盒只留给追梦神器"],
  ["已入库材料", 56, "已锁定", "每大陆7件", "引用", "掉率／数量", "不得改Idx或Looks", "通用、稀有、剧情印记和四级证物"],
  ["大陆收藏材料", 8, "名称定稿", "全怪独立判定、不可装备、只供高价值图鉴", "是", "编码／奖励／爆率", "不得借用现有剧情印记冒充", "暂不占冻结预留号"],
  ["追梦神器", 6, "槽位永久保留", "第二大陆以后全怪公共奖池", "引用", "具体概率", "不得覆盖用户本机六槽部位", "一次触发后六选一"],
];
guide.getRange("B8").formulas = [["=COUNTA('02_怪物与专属'!$A$5:$A$" + monsterEnd + ")"]];
guide.getRange("B9").formulas = [["=COUNTA('02_怪物与专属'!$N$5:$N$" + monsterEnd + ")"]];
styleHeader(guide.getRange("A4:H4"));
styleBody(guide.getRange("A5:H12"), 30);
guide.getRange("C5:C12").format.fill = theme.green;
guide.getRange("A15:H22").values = [
  ["执行规则", "内容", null, null, null, null, null, null],
  ["自主权限", "怪物名、专属名、部位和分类由总设计窗口直接决定，不再逐项请示；只有编码冲突、引擎不支持或改变全服经济结构时才升级为阻塞。", null, null, null, null, null, null],
  ["数值边界", "怪物属性、装备属性、货币、消耗数量和具体掉率全部延后，外围来源框架完成后再统一平衡。", null, null, null, null, null, null],
  ["效率容差", "打怪效率不再执行全服统一小于15%的硬约束；最终允许流派、装备和养成形成较大效率差，但仍要避免无法通关或单一乘区彻底碾压全部选择。", null, null, null, null, null, null],
  ["BOSS兼掉", "地图BOSS和守关BOSS保留本体专属池，并另行兼掉本地图普通怪专属；两个奖池不得合并成一次随机。", null, null, null, null, null, null],
  ["重复专属", "重复专属继续用于任务、称号、分解或合成，不因一怪一专属而变成无用垃圾。", null, null, null, null, null, null],
  ["极稀有装备", "追梦六神器延续极低概率公共奖池；触发后从六件中随机一件，并自动进入背包的既有脚本规则由服务端继续执行。", null, null, null, null, null, null],
  ["来源依据", "第3—8大陆使用结构化地图表复核；第9—10大陆按最新《第3至10大陆_地图大小与刷怪规划总览》层序；旧13大陆待安排表废止。", null, null, null, null, null, null],
];
guide.getRange("A15:H15").merge(true);
guide.getRange("A16:A22").format = { fill: theme.gold, font: { name: "Noto Sans SC Thin", bold: true, color: "#FFFFFF" }, verticalAlignment: "center" };
guide.getRange("B16:H22").merge(true);
styleBody(guide.getRange("A15:H22"), 34);
setWidths(guide, { A: 20, B: 15, C: 14, D: 34, E: 18, F: 22, G: 32, H: 36 });
guide.freezePanes.freezeRows(4);

title(maps, "A1:O1", "第3—10大陆地图与怪物覆盖");
subtitle(maps, "A2:O2", "每行是一张真实地图。普通、稀有、地图BOSS和守关数量由怪物总表按地图号自动统计；地图名称和层序不在本表修改。");
maps.getRange("A4:O4").values = [["记录ID", "大陆ID", "大陆", "组序", "地图组", "层序", "地图号", "地图名称", "普通怪", "稀有怪", "地图BOSS", "守关BOSS", "合计怪种", "状态", "备注"]];
maps.getRange("A" + mapStart + ":H" + mapEnd).values = mapRows.map((row) => [row.recordId, row.continentId, row.continent, row.groupOrder, row.group, row.layer, row.mapId, row.mapName]);
maps.getRange("N" + mapStart + ":O" + mapEnd).values = mapRows.map((row) => ["已完成／来源已分配", "地图属性、尺寸和刷新数量不在本表修改"]);
const mapFormulas = [];
for (let row = mapStart; row <= mapEnd; row++) {
  mapFormulas.push([
    "=COUNTIFS('02_怪物与专属'!$G$" + monsterStart + ":$G$" + monsterEnd + ",$G" + row + ",'02_怪物与专属'!$K$" + monsterStart + ":$K$" + monsterEnd + ",\"普通\")",
    "=COUNTIFS('02_怪物与专属'!$G$" + monsterStart + ":$G$" + monsterEnd + ",$G" + row + ",'02_怪物与专属'!$K$" + monsterStart + ":$K$" + monsterEnd + ",\"稀有\")",
    "=COUNTIFS('02_怪物与专属'!$G$" + monsterStart + ":$G$" + monsterEnd + ",$G" + row + ",'02_怪物与专属'!$K$" + monsterStart + ":$K$" + monsterEnd + ",\"地图BOSS\")",
    "=COUNTIFS('02_怪物与专属'!$G$" + monsterStart + ":$G$" + monsterEnd + ",$G" + row + ",'02_怪物与专属'!$K$" + monsterStart + ":$K$" + monsterEnd + ",\"守关BOSS\")",
    "=SUM(I" + row + ":L" + row + ")",
  ]);
}
maps.getRange("I" + mapStart + ":M" + mapEnd).formulas = mapFormulas;
styleHeader(maps.getRange("A4:O4"));
styleBody(maps.getRange("A" + mapStart + ":O" + mapEnd));
addTable(maps, "A4:O" + mapEnd, "MapCoverageLedger");
maps.getRange("N" + mapStart + ":N" + mapEnd).format.fill = theme.green;
setWidths(maps, { A: 17, B: 10, C: 20, D: 8, E: 20, F: 8, G: 12, H: 22, I: 10, J: 10, K: 12, L: 12, M: 12, N: 22, O: 42 });
maps.freezePanes.freezeRows(4);
maps.freezePanes.freezeColumns(8);

title(monsters, "A1:Z1", "第3—10大陆怪物、定向专属与材料关系");
subtitle(monsters, "A2:Z2", "每行锁定一只怪的准确地图、类别、族群、战斗定位、唯一专属、装备部位和材料池。黄色普通、蓝色稀有、粉色地图BOSS、红色守关BOSS。所有数值列均明确延后。");
monsters.getRange("A4:Z4").values = [[
  "记录ID", "大陆ID", "大陆", "组序", "地图组", "层序", "地图号", "地图名称", "怪物名称", "颜色", "类别", "族群", "战斗定位",
  "定向专属", "专属部位", "通用材料", "稀有／剧情材料", "身份证物", "大陆收藏材料", "BOSS兼掉本图普通怪专属",
  "六神器公共池", "名称状态", "怪物／模型编码", "装备来源编号", "属性与爆率", "备注",
]];
monsters.getRange("A" + monsterStart + ":Z" + monsterEnd).values = monsterSheetRows;
styleHeader(monsters.getRange("A4:Z4"));
styleBody(monsters.getRange("A" + monsterStart + ":Z" + monsterEnd));
addTable(monsters, "A4:Z" + monsterEnd, "MonsterExclusiveLedger");
monsters.getRange("J" + monsterStart + ":J" + monsterEnd).conditionalFormats.add("containsText", { text: "黄色", format: { fill: "#FFF2CC", font: { color: "#7F6000", bold: true } } });
monsters.getRange("J" + monsterStart + ":J" + monsterEnd).conditionalFormats.add("containsText", { text: "蓝色", format: { fill: "#D9EAF7", font: { color: "#1F4E78", bold: true } } });
monsters.getRange("J" + monsterStart + ":J" + monsterEnd).conditionalFormats.add("containsText", { text: "粉色", format: { fill: "#FCE4EC", font: { color: "#9C2550", bold: true } } });
monsters.getRange("J" + monsterStart + ":J" + monsterEnd).conditionalFormats.add("containsText", { text: "红色", format: { fill: "#F4CCCC", font: { color: "#9C0006", bold: true } } });
monsters.getRange("V" + monsterStart + ":V" + monsterEnd).format.fill = theme.green;
monsters.getRange("W" + monsterStart + ":Y" + monsterEnd).format.fill = theme.yellow;
setWidths(monsters, { A: 15, B: 10, C: 18, D: 8, E: 18, F: 8, G: 12, H: 20, I: 24, J: 9, K: 13, L: 12, M: 14, N: 24, O: 12, P: 18, Q: 26, R: 20, S: 22, T: 20, U: 18, V: 14, W: 20, X: 22, Y: 18, Z: 46 });
monsters.freezePanes.freezeRows(4);
monsters.freezePanes.freezeColumns(9);

title(materials, "A1:M1", "第3—10大陆材料来源");
subtitle(materials, "A2:M2", "每大陆引用7件已经正式入库的材料，并新增1件仅用于大陆图鉴的收藏材料名称。收藏材料暂不占用冻结的材料Idx和Items Looks。");
materials.getRange("A4:M4").values = [["记录ID", "大陆ID", "大陆", "逻辑材料ID", "材料名称", "类别", "Idx", "Items Looks", "主产怪物", "来源范围", "用途", "状态", "备注"]];
materials.getRange("A" + materialStart + ":M" + materialEnd).values = materialRows.map((row) => [
  row.recordId, row.continentId, row.continent, row.logicalId, row.name, row.category, row.idx, row.looks,
  row.producer, row.scope, row.purpose, row.status, row.note,
]);
styleHeader(materials.getRange("A4:M4"));
styleBody(materials.getRange("A" + materialStart + ":M" + materialEnd));
addTable(materials, "A4:M" + materialEnd, "MaterialSourceLedger");
materials.getRange("L" + materialStart + ":L" + materialEnd).conditionalFormats.add("containsText", { text: "已正式入库", format: { fill: theme.green, font: { color: "#256029", bold: true } } });
materials.getRange("L" + materialStart + ":L" + materialEnd).conditionalFormats.add("containsText", { text: "待分配", format: { fill: theme.yellow, font: { color: "#7F6000", bold: true } } });
setWidths(materials, { A: 22, B: 10, C: 18, D: 30, E: 22, F: 22, G: 10, H: 14, I: 28, J: 24, K: 38, L: 24, M: 48 });
materials.freezePanes.freezeRows(4);
materials.freezePanes.freezeColumns(5);

title(slots, "A1:I1", "定向专属部位分布");
subtitle(slots, "A2:I2", "统计只覆盖常规允许的11个部位。马牌、战鼓／军鼓、灵玉、宝石、生肖和六个时装首饰盒均不进入怪物专属分配。");
slots.getRange("A4:I4").values = [["大陆ID", "大陆", "部位", "普通", "稀有", "地图BOSS", "守关BOSS", "合计", "备注"]];
const slotRows = [];
for (const continentId of continentIds) {
  for (const slot of allowedSlots) slotRows.push([continentId, expected[continentId].continent, slot, null, null, null, null, null, "结构统计；不代表部位强弱"]);
}
const slotStart = 5;
const slotEnd = slotStart + slotRows.length - 1;
slots.getRange("A" + slotStart + ":C" + slotEnd).values = slotRows.map((row) => row.slice(0, 3));
slots.getRange("I" + slotStart + ":I" + slotEnd).values = slotRows.map((row) => [row[8]]);
const slotFormulas = [];
for (let row = slotStart; row <= slotEnd; row++) {
  slotFormulas.push([
    "=COUNTIFS('02_怪物与专属'!$B$" + monsterStart + ":$B$" + monsterEnd + ",$A" + row + ",'02_怪物与专属'!$O$" + monsterStart + ":$O$" + monsterEnd + ",$C" + row + ",'02_怪物与专属'!$K$" + monsterStart + ":$K$" + monsterEnd + ",\"普通\")",
    "=COUNTIFS('02_怪物与专属'!$B$" + monsterStart + ":$B$" + monsterEnd + ",$A" + row + ",'02_怪物与专属'!$O$" + monsterStart + ":$O$" + monsterEnd + ",$C" + row + ",'02_怪物与专属'!$K$" + monsterStart + ":$K$" + monsterEnd + ",\"稀有\")",
    "=COUNTIFS('02_怪物与专属'!$B$" + monsterStart + ":$B$" + monsterEnd + ",$A" + row + ",'02_怪物与专属'!$O$" + monsterStart + ":$O$" + monsterEnd + ",$C" + row + ",'02_怪物与专属'!$K$" + monsterStart + ":$K$" + monsterEnd + ",\"地图BOSS\")",
    "=COUNTIFS('02_怪物与专属'!$B$" + monsterStart + ":$B$" + monsterEnd + ",$A" + row + ",'02_怪物与专属'!$O$" + monsterStart + ":$O$" + monsterEnd + ",$C" + row + ",'02_怪物与专属'!$K$" + monsterStart + ":$K$" + monsterEnd + ",\"守关BOSS\")",
    "=SUM(D" + row + ":G" + row + ")",
  ]);
}
slots.getRange("D" + slotStart + ":H" + slotEnd).formulas = slotFormulas;
styleHeader(slots.getRange("A4:I4"));
styleBody(slots.getRange("A" + slotStart + ":I" + slotEnd));
addTable(slots, "A4:I" + slotEnd, "SlotDistributionLedger");
setWidths(slots, { A: 11, B: 20, C: 14, D: 10, E: 10, F: 12, G: 12, H: 10, I: 36 });
slots.freezePanes.freezeRows(4);
slots.freezePanes.freezeColumns(3);

title(pools, "A1:H1", "独立掉落池与追梦六神器保留");
subtitle(pools, "A2:H2", "以下奖池分别判定，禁止为了省事把专属、材料、大陆收藏或六神器合成一个总随机池。追梦六件具体部位一律以用户本机现行装备库为准。");
pools.getRange("A4:H9").values = [
  ["奖池", "适用对象", "触发方式", "产物", "是否受人物爆率", "是否占本体专属", "本轮状态", "说明"],
  ["怪物本体专属池", "全部怪物", "按该怪物专属规则", "本行唯一专属装备", "后期统一确认", "是", "来源已定", "一怪一专属"],
  ["BOSS兼掉池", "地图BOSS／守关BOSS", "与本体专属分开判定", "本地图普通怪专属", "后期统一确认", "否", "规则已定", "不得挤掉BOSS本体专属"],
  ["材料池", "按普通／稀有／地图BOSS／守关分类", "各材料独立配置", "已入库7类材料", "后期统一确认", "否", "来源已定", "数量和概率延后"],
  ["大陆收藏池", "该大陆全部怪物", "独立极低概率判定", "大陆收藏材料", "后期统一确认", "否", "名称已定", "不可装备；只供高价值图鉴"],
  ["六神器公共池", "第二大陆及以后全部怪物", "TXT 1/x RANDOM触发一次后池内六选一", "6件大卢恩追梦神器之一", "是", "否", "既有规则", "不是每件分别执行一次1/x"],
];
styleHeader(pools.getRange("A4:H4"));
styleBody(pools.getRange("A5:H9"), 34);
addTable(pools, "A4:H9", "IndependentDropPools");
pools.getRange("A12:H12").values = [["记录ID", "追梦神器名称", "现有来源编号", "现行部位", "掉落范围", "池内方式", "状态", "执行警告"]];
pools.getRange("A13:H18").values = artifacts.map(([id, name, sourceNumber]) => [
  id, name, sourceNumber, "用户本机六个时装首饰盒槽位之一", "第二大陆及以后全部怪物", "公共池触发后六选一",
  "名称保留／部位不得覆盖", "旧表显示灵玉属于历史底板错误；本表不写入具体槽号",
]);
styleHeader(pools.getRange("A12:H12"));
styleBody(pools.getRange("A13:H18"), 30);
addTable(pools, "A12:H18", "DreamArtifactsReserve");
pools.getRange("G13:G18").format.fill = theme.red;
setWidths(pools, { A: 22, B: 28, C: 16, D: 38, E: 30, F: 30, G: 26, H: 58 });
pools.freezePanes.freezeRows(4);

const staticChecks = {
  "怪物名称重复": duplicates(monsterRows.map((row) => row.name)).length,
  "专属装备名称重复": duplicates(monsterRows.map((row) => row.exclusive)).length,
  "地图号重复": duplicates(mapRows.map((row) => row.mapId)).length,
  "第一二大陆怪名碰撞": monsterCollisions.length,
  "现有装备名称碰撞": equipmentCollisions.length,
  "禁用部位": monsterRows.filter((row) => forbiddenSlots.some((slot) => row.slot.includes(slot))).length,
  "大陆收藏材料重名": duplicates(batches.map((batch) => batch.continent_collectible.name)).length,
};
title(checks, "A1:E1", "静态校验报告");
subtitle(checks, "A2:E2", "通过只代表名称、数量、地图归属、材料引用和部位约束正确；不代表怪物模型、刷新脚本、装备编码、属性或实际掉落已经部署。");
checks.getRange("A4:E4").values = [["检查项", "期望值", "实际值", "结果", "说明"]];
const checkRows = [
  ["大陆数", 8, 8, null, "C03—C10"],
  ["地图组数", 38, batches.reduce((sum, batch) => sum + batch.groups.length, 0), null, "现行10大陆结构"],
  ["地图数", 144, null, null, "逐层唯一地图号"],
  ["怪物总数", 464, null, null, "38组×12＋8守关"],
  ["普通怪", 228, null, null, "每组6只"],
  ["稀有怪", 152, null, null, "每组4只"],
  ["地图BOSS", 76, null, null, "每组2只"],
  ["守关BOSS", 8, null, null, "每大陆1只"],
  ["一怪一专属", 464, null, null, "专属名称唯一"],
  ["已入库材料引用", 56, null, null, "8大陆×7件"],
  ["大陆收藏材料", 8, null, null, "名称定稿、编码待分配"],
  ["怪物名称重复", 0, staticChecks["怪物名称重复"], null, "C3—C10内部"],
  ["专属装备名称重复", 0, staticChecks["专属装备名称重复"], null, "C3—C10内部"],
  ["地图号重复", 0, staticChecks["地图号重复"], null, "C3—C10内部"],
  ["第一二大陆怪名碰撞", 0, staticChecks["第一二大陆怪名碰撞"], null, "与现行97怪比对"],
  ["现有装备名称碰撞", 0, staticChecks["现有装备名称碰撞"], null, "与160制式＋105专属比对"],
  ["禁用部位", 0, staticChecks["禁用部位"], null, "马牌／战鼓／军鼓／灵玉／宝石／时装首饰盒／生肖"],
  ["大陆收藏材料重名", 0, staticChecks["大陆收藏材料重名"], null, "含现有材料库碰撞检查"],
];
const checkStart = 5;
const checkEnd = checkStart + checkRows.length - 1;
checks.getRange("A" + checkStart + ":C" + checkEnd).values = checkRows.map((row) => row.slice(0, 3));
checks.getRange("E" + checkStart + ":E" + checkEnd).values = checkRows.map((row) => [row[4]]);
checks.getRange("C7").formulas = [["=COUNTA('01_地图总览'!$A$" + mapStart + ":$A$" + mapEnd + ")"]];
checks.getRange("C8").formulas = [["=COUNTA('02_怪物与专属'!$A$" + monsterStart + ":$A$" + monsterEnd + ")"]];
checks.getRange("C9").formulas = [["=COUNTIF('02_怪物与专属'!$K$" + monsterStart + ":$K$" + monsterEnd + ",\"普通\")"]];
checks.getRange("C10").formulas = [["=COUNTIF('02_怪物与专属'!$K$" + monsterStart + ":$K$" + monsterEnd + ",\"稀有\")"]];
checks.getRange("C11").formulas = [["=COUNTIF('02_怪物与专属'!$K$" + monsterStart + ":$K$" + monsterEnd + ",\"地图BOSS\")"]];
checks.getRange("C12").formulas = [["=COUNTIF('02_怪物与专属'!$K$" + monsterStart + ":$K$" + monsterEnd + ",\"守关BOSS\")"]];
checks.getRange("C13").formulas = [["=COUNTA('02_怪物与专属'!$N$" + monsterStart + ":$N$" + monsterEnd + ")"]];
checks.getRange("C14").formulas = [["=COUNTIF('03_材料来源'!$L$" + materialStart + ":$L$" + materialEnd + ",\"已正式入库\")"]];
checks.getRange("C15").formulas = [["=COUNTIF('03_材料来源'!$F$" + materialStart + ":$F$" + materialEnd + ",\"大陆收藏材料\")"]];
checks.getRange("D" + checkStart).formulas = [["=IF(B" + checkStart + "=C" + checkStart + ",\"通过\",\"异常\")"]];
checks.getRange("D" + checkStart + ":D" + checkEnd).fillDown();
styleHeader(checks.getRange("A4:E4"));
styleBody(checks.getRange("A" + checkStart + ":E" + checkEnd), 28);
addTable(checks, "A4:E" + checkEnd, "ValidationLedger");
checks.getRange("D" + checkStart + ":D" + checkEnd).conditionalFormats.add("containsText", { text: "通过", format: { fill: theme.green, font: { color: "#256029", bold: true } } });
checks.getRange("D" + checkStart + ":D" + checkEnd).conditionalFormats.add("containsText", { text: "异常", format: { fill: theme.red, font: { color: "#9C0006", bold: true } } });
if (slotCoverageWarnings.length) {
  checks.getRange("A26:E26").values = [["非阻塞提示", "内容", null, null, null]];
  checks.getRange("B27:E27").merge();
  checks.getRange("A27:E27").values = [["部位覆盖", slotCoverageWarnings.join("；"), null, null, null]];
  styleHeader(checks.getRange("A26:E26"));
  styleBody(checks.getRange("A27:E27"), 40);
}
setWidths(checks, { A: 28, B: 14, C: 14, D: 14, E: 62 });
checks.freezePanes.freezeRows(4);

title(codes, "A1:G1", "编码需求、冻结范围与后续施工");
subtitle(codes, "A2:G2", "本轮只做名称与来源框架，不抢占装备或材料编码。正式分配前必须回读装备权威库和游戏实库；编码不足时再按准确用途和数量向用户申请。");
codes.getRange("A4:G11").values = [
  ["对象", "编码类型", "需求数", "已锁定", "待分配", "状态", "处理规则"],
  ["C3—C10怪物", "怪物／模型编号", 464, 0, 464, "待平台选型", "按族群和战斗定位选择现有模型，名称不得重复"],
  ["C3—C10一怪一专属", "装备来源编号", 464, 0, 464, "待实库回读", "先查装备编码权威库，再查Items／StateItem／DnItems三库"],
  ["既有大陆材料", "材料Idx", 56, 56, 0, "已锁定", "C3—C10现有Idx 916—971中的对应56件，不改号"],
  ["既有材料图标", "Items Looks", 56, 56, 0, "已锁定", "对应Looks 6407—6462，不得分配给装备"],
  ["大陆收藏材料", "材料Idx＋Items Looks", 8, 0, 8, "名称定稿／待编码", "Idx 972—983仍为冻结预留，不在本表直接占用"],
  ["追梦六神器", "用户本机时装首饰盒部位", 6, 6, 0, "永久保留", "只按名称引用，任何导入表不得覆盖本机部位"],
  ["怪物／装备属性", "数值字段", 464, 0, 464, "延后", "外围框架完成后统一平衡"],
];
styleHeader(codes.getRange("A4:G4"));
styleBody(codes.getRange("A5:G11"), 30);
addTable(codes, "A4:G11", "CodeDemandLedger");
codes.getRange("F5:F6").format.fill = theme.yellow;
codes.getRange("F7:F8").format.fill = theme.green;
codes.getRange("F9:F11").format.fill = theme.yellow;
codes.getRange("A14:G20").values = [
  ["冻结／保留对象", "起点", "终点", "数量", "当前用途", "可否直接使用", "说明"],
  ["材料Idx预留", 972, 983, 12, "冻结预留", "否", "大陆收藏材料需要8个，但正式分配前仍需确认实库"],
  ["材料Items Looks占用", 6398, 6462, 65, "65件批次A材料", "否", "与装备候选数字段重叠，材料写入优先"],
  ["六个时装首饰盒", null, null, 6, "追梦神器", "否", "具体槽位以用户本机为最高依据"],
  ["常规怪物专属禁配", null, null, 4, "马牌／战鼓／灵玉／宝石", "否", "不得通过改名规避禁配"],
  ["第一二大陆成品", null, null, 5, "既有怪物／装备／爆率／资源表", "否", "本轮不修改其任何内容或哈希"],
  ["数值平衡", null, null, null, "后续集中施工", "否", "先完成NPC、怪物、装备、材料和来源框架"],
];
styleHeader(codes.getRange("A14:G14"));
styleBody(codes.getRange("A15:G20"), 30);
addTable(codes, "A14:G20", "FrozenRangesLedger");
setWidths(codes, { A: 30, B: 16, C: 16, D: 12, E: 34, F: 22, G: 66 });
codes.freezePanes.freezeRows(4);

await fs.mkdir(outputDir, { recursive: true });
await fs.mkdir(previewDir, { recursive: true });
const output = await SpreadsheetFile.exportXlsx(book);
await output.save(outputPath);

const renderJobs = [
  [guide, "A1:H22", "00_使用说明"],
  [maps, "A1:O35", "01_地图总览_首段"],
  [maps, "A119:O" + mapEnd, "01_地图总览_末段"],
  [monsters, "A1:Z34", "02_怪物与专属_首段"],
  [monsters, "A" + (monsterEnd - 29) + ":Z" + monsterEnd, "02_怪物与专属_末段"],
  [materials, "A1:M36", "03_材料来源_首段"],
  [materials, "A37:M" + materialEnd, "03_材料来源_末段"],
  [slots, "A1:I35", "04_部位统计"],
  [pools, "A1:H18", "05_独立奖池与六神器"],
  [checks, "A1:E28", "06_校验报告"],
  [codes, "A1:G20", "07_编码与后续"],
];
for (const [sheet, range, filename] of renderJobs) {
  const image = await book.render({ sheetName: sheet.name, range, scale: 1, format: "png" });
  await fs.writeFile(path.join(previewDir, filename + ".png"), new Uint8Array(await image.arrayBuffer()));
}

const keyInspect = await book.inspect({
  kind: "table",
  range: "06_校验报告!A4:E22",
  include: "values,formulas",
  tableMaxRows: 24,
  tableMaxCols: 6,
  maxChars: 12000,
});
const formulaErrors = await book.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 300 },
  summary: "final formula error scan",
});
const verify = {
  outputPath,
  previewDir,
  counts: {
    continents: 8,
    groups: 38,
    maps: mapRows.length,
    monsters: monsterRows.length,
    ordinary: totalRarity["普通"],
    rare: totalRarity["稀有"],
    mapBoss: totalRarity["地图BOSS"],
    finalBoss: totalRarity["守关BOSS"],
    exclusives: monsterRows.length,
    formalMaterials: materialRows.filter((row) => row.status === "已正式入库").length,
    continentCollectibles: batches.length,
  },
  duplicates: staticChecks,
  slotCoverageWarnings,
  keyInspect: keyInspect.ndjson,
  formulaErrors: formulaErrors.ndjson,
};
await fs.writeFile(verifyPath, JSON.stringify(verify, null, 2), "utf8");
console.log(JSON.stringify(verify, null, 2));
